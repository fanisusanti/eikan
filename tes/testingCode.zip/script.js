setTimeout(function () {
    const name = 'Andri';
    alert('Message for you from ' + name + '\n\n\nUDAH OKE SIH \nTERNYATA GAK DI LOOPING JUGA BISA -_- \nValidasi Size : ok \nValidasi Ekstension : ok');
    dialog
}, 2000);